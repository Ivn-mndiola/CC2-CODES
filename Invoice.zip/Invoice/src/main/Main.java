//Ivan Dave A. Mendiola
// CC2 Lab1

package main;

public class Main {

	public static void main(String[] args) {
		// Store Information
        System.out.println("Store Name: \"Andoks\"");
        System.out.println("Address: 06 Atok, Benguet\n");
        System.out.println("Contact No.: +631234567\n");

        // Itemized List
        System.out.println("Item\t\t\t\tQuantity\t\tPrice");
        System.out.println("-----------------------------------------------------------------");
        System.out.println("Dokito Burger\t\t\t3\t\t\t 291.00 ₱");
        System.out.println("Litson Manok\t\t\t2\t\t\t 738.00 ₱");
        System.out.println("Litson Baka\t\t\t1\t\t\t 416.00 ₱");
        System.out.println("Chicken Ala Bone\t\t12\t\t\t 132.00 ₱");
        
        //Total Amount
        System.out.println("-----------------------------------------------------------------");
        //Thank You Note
        System.out.println("Thank you for purchasing!\t\t\tTotal: 1,570.00\n");
     

		
	}
}
