//IVAN DAVE A. MENDIOLA
//CC2 CITCS-1N-A

package Calculator;

import java.util.Scanner;
public class Calculator {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		//We ask the user for their input
		System.out.print("Enter the total purchase amount: PHP ");
	    
		//
		float totalAmount = sc.nextFloat();
	    float discount = 0.0f;
	    float finalPrice;
	    
	    

	    //
	    if (totalAmount < 1000) {
	        discount = 0.0f;
	    } else if (totalAmount >= 1000 && totalAmount <= 5000) {
	        discount = 0.05f; // 5% discount
	    } else if (totalAmount >= 5001 && totalAmount <= 10000) {
	        discount = 0.10f; // 10% discount
	    } else if (totalAmount >= 10000) {
	        discount = 0.15f; // 15% discount
	    }

	    float discountAmount = totalAmount * discount;
	    finalPrice = totalAmount - discountAmount;
	    
	    //
	    System.out.println("Discount applied: " + (int)(discount * 100) + "%");
	    System.out.println("Final price after discount: PHP " + finalPrice);
        
	}
}