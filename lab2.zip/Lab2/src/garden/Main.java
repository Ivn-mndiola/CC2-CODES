package garden;

public class Main {

	public static void main(String[] args) {
		
		//Estimated measurement of a rectangular garden
		int length = 20;
		float width = 15;
	
		float area = length * width; // Area = length * width
		float perimeter = 2 * (length + width); // Perimeter = 2 * (length + width)
		
		//Prints out the length, width, area, perimeter
		System.out.println("The length of the garden is: " + length + " meters");
        System.out.println("The width of the garden is: " + width + " meters");
        System.out.println("The area of the garden is: " + area + " square meters");
        System.out.println("The perimeter of the garden is: " + perimeter + " meters");
		
					
	}

}
