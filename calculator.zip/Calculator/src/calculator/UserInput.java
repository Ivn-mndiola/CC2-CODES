//Ivan Dave A. Mendiola
//CC2-1N-A

package calculator;

import java.util.Scanner;

public class UserInput {

	public static void main(String[] args) {
		
		Scanner obj = new Scanner(System.in);
		
		//Declaring varibles for item prices and quantities
		double Item1, Item2, Item3;
		double itemPrice1, itemPrice2, itemPrice3;
		
		//Declaring variables for Subtotal, Discount, SalesTax, FinalTotal
		double Subtotal =  (100 * 2) + (50 * 3) + (150 * 1); // Calculating the total cost of each item and qty 
		double Discount = (0.05 * Subtotal); //Calculating the 5% of 500
		double salestax = 0.12 * (Subtotal-25); // Calculating the 12% of 500-25 = 12% of 475
		double finalTotal = (475 + 57); // Calculating Final Total
		
        // Taking user input for item prices and quantities
		System.out.print("Enter the price of item 1: ");
		itemPrice1 = obj.nextDouble();
		
		System.out.print("Enter the quantity of item 1: ");
		Item1 = obj.nextDouble();
		
		System.out.print("Enter the price of item 2: ");
		itemPrice2 = obj.nextDouble();
		
		System.out.print("Enter the quantity of item 2: ");
		Item2 = obj.nextDouble();
		
		System.out.print("Enter the price of item 3: ");
		itemPrice3 = obj.nextDouble();
		
		System.out.print("Enter the quantity of item 3: ");
		Item3 = obj.nextDouble();
		
		//this prints out the calculated result of the Subtotal, Discount, SalesTax, Final Total
		System.out.println("Subtotal: " +Subtotal);
		System.out.println("Discount: " +Discount);
		System.out.println("Sales Tax.: " +salestax);
		System.out.println("Final Total: " +finalTotal);
		
	}

}
