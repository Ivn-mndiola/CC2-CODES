//Ivan Dave A. Mendiola
//CITCS 1N-A
//SEPTEMBER 5, 2024

package workingvariables;

public class main {

	public static void main(String[] args) {
		
		String name = "Ivan Dave A. Mendiola";
        int age = 18;
        char grade = 'A';
        float gpa = 89f;
        boolean grad = false;
        int a = 5;
        int b = 30;

        
        int sum = a+b;
        int difference = a-b;
        float product = a*b; 
        float quotient =(float) a/b;

    
        System.out.print("Hello, my name is " + name );
        System.out.println(" I am " + age + " years old");
        System.out.println("I have a GPA of " + gpa);
        System.out.println("and my grade is " + grade);
        System.out.println("Graduated? " + grad);
        System.out.println("Sum: " + sum);
        System.out.println("Difference: " + difference);
        System.out.println("Product: " + product);
        System.out.println("Quotient: " + quotient);
		
	}
	
}
