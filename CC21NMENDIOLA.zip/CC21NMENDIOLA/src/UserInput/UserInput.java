package UserInput;
import java.util.Scanner;

public class UserInput {

	
	public static void main(String[] args) {
	 
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter your name: ");
		String name = sc.nextLine(); 
		
		System.out.print("Enter your middle initial: ");
		char mi = sc.next().charAt(0);
		
		System.out.print("Enter your Age: ");
		int age = sc.nextInt();
		
		System.out.print("What is your gpa: ");
		double gpa = sc.nextDouble();
		
		System.out.println("Your name is: " +name);
		System.out.println("Your middle initial is: " +mi);
		System.out.println("Enter your Age: " +age);
		System.out.println("Your Gpa is: " +gpa);
		
		
	}

}
